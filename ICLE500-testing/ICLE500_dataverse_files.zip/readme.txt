The contents of this folder are as follows:

- A pdf file explaining how the texts in the ICLE_500 sample were selected and assessed
- Two spreadsheets (identical except that the xlsx file contains column name explanations) with the ICLE_500 metadata and comparative judgement assessment scores
- A "Texts" folder containing the 500 texts selected for this data release
- A technical report on the rubric-based assessment of these texts, written by Paraskevi Kanistra and Charalambos Kollias.